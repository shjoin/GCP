import sys

print("the name of the program is ", sys.argv[0])
print("argument list :", sys.argv)