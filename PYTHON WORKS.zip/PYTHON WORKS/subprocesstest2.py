import subprocess


subprocess.run('dir',shell=True)
