import MyFuncCalculation

def funcCall():
 return_result= MyFuncCalculation.myfunc(100)
 print('funcCall',return_result)


 if __name__ == "main":
     funcCall()


