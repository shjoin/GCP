import numpy


def myfunc(var_num):
    print("myfunc()" ,var_num+100)
    return var_num+10





